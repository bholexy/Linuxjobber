from django.contrib import admin

# Models from main website application
from .models import FAQ

# Models from Courses application


admin.site.register(FAQ)