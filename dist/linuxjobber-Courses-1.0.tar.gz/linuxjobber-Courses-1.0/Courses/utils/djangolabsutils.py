import zipfile
import os
import sys
import shutil
import glob
import subprocess
import re
import time
import tarfile


from Courses.models import *



from tempfile import mkstemp
from shutil import move
from os import fdopen, remove

from selenium import webdriver

os.environ.setdefault("_SETTINGS_MODULE","server.settings")


############################################################################################################################################################
# Construction of projects directories/paths.
############################################################################################################################################################
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
APPLICATION_DIR = os.path.join(BASE_DIR, 'Courses')
PROJECT_DIR = os.path.join(BASE_DIR, 'Linuxjobber')
PROJECT_MEDIA_DIR = os.path.join(BASE_DIR, 'media/uploads') # Directory that contains projects media
MEDIA_DIR = os.path.join(APPLICATION_DIR, 'media') #Directory that contains media exclucive to DjangoLabs Application
VERIFYD_BASE_DIR = os.path.join(BASE_DIR, 'verifyd') #Project to install and launch packaged django applications.
VERIFYD_PROJECT_DIR = os.path.join(VERIFYD_BASE_DIR, 'verifyd') #Verifyd project directory containing the settings.py and urls.py

############################################################################################################################################################


#--------------------------------------------------------------------------------------------------------
#FUNCTIONS
#--------------------------------------------------------------------------------------------------------
def replace(file_path, pattern, subst):
	fh, abs_path = mkstemp()
	with fdopen(fh,'w') as new_file:
		with open(file_path) as old_file:
			for line in old_file:
				new_file.write(line.replace(pattern,subst))
	remove(file_path)
	move(abs_path, file_path)

def save_grade(lab_number, mark, current_user, grade):
	course_topic = CourseTopic.objects.get(pk = lab_number)
	report = GradesReport(score = mark, course_topic = course_topic, user_id = current_user, grade = grade)
	report.save()


#-------------------------------------------------------------------------------------------------------

def grade_django_lab10(file, lab_number, current_user):
	file_upload = ''

	if file.name.endswith('.zip'):
		file_upload = os.path.join(PROJECT_MEDIA_DIR, current_user.username + '_' + lab_number + '.zip')
	else:
		file_upload = os.path.join(PROJECT_MEDIA_DIR, current_user.username + '_' + lab_number + '.gz')


	app_name = current_user.last_name + 'scrumy'
	grade = ''
	mark = 0

	try:
		subprocess.call([sys.executable, "-m", "pip", "install", file_upload])

		if file.name.endswith('tar.gz'):
			extracted_file = file.name.rstrip('.tar.gz')
			tar = tarfile.open('file_upload')
			tar.extractall(MEDIA_DIR)
			tar.close()

			task_file = os.path.join(MEDIA_DIR, 'django-'+app_name+'-0.1/'+app_name+'/'+app_name+'.py')

			os.system('python '+task_file)
			
		elif file.name.endswith('.zip'):
			extracted_file = file.name.rstrip('.zip')
			try:
				zfile = zipfile.ZipFile(file)
			except zipfile.BadZipfile as ex:
				print("%s no a zip file" % file)

			zfile.extractall(MEDIA_DIR)
			with open(os.path.join(MEDIA_DIR, extracted_file + '/django_' + current_user.last_name + 'scrumy.egg-info/SOURCES.txt'), 'r') as source_file:
				for eachline in source_file:
					if eachline.rstrip('\n') == 'MANIFEST.in' or eachline.rstrip('\n') == 'README.rst' or eachline.rstrip('\n') == 'setup.py' or eachline.rstrip('\n') == current_user.last_name + 'scrumy/__init__.py':
						count += 1
















		print ("Initializing webdriver...")
		driver = webdriver.Chrome(os.path.join(BASE_DIR, 'chromedriver.exe'))
		print ("webdriver initialized")

		driver.get("http://127.0.0.1:8000/"+app_name)

		html = driver.find_element_by_xpath('//body').get_attribute('innerHTML')
		
		
		if html.lower().startswith('scrumygoals object'):
			grade = "Passed"
			mark = 100
			print('Passed')
		else:
			print('Failed')
			grade = 'Failed'
			mark = 0
		save_grade(lab_number, mark, current_user, grade) 
	except Exception as e:
		grade = 'Failed'
		mark = 0
		save_grade(lab_number, mark, current_user, grade)
		print(e)
	finally:
		os.remove(file_upload)

	return(grade)







def grade_django_lab9(file, lab_number, current_user):

	file_upload = ''

	if file.name.endswith('.zip'):
		file_upload = os.path.join(PROJECT_MEDIA_DIR, current_user.username + '_' + lab_number + '.zip')
	else:
		file_upload = os.path.join(PROJECT_MEDIA_DIR, current_user.username + '_' + lab_number + '.gz')

	app_name = current_user.last_name + 'scrumy'
	grade = ''
	mark = 0
	task_1 = 0
	task_2 = 0
	task_3 = 0
	task_4 = 0
	task_5 = 0

	subprocess.call(["pip", "install", file_upload])

	os.system('python manage.py makemigrations ' + app_name)
	os.system('python manage.py migrate')

	os.remove(file_upload)

	driver = webdriver.Chrome(os.path.join(BASE_DIR, 'chromedriver.exe'))

	try:
		driver.get("http://127.0.0.1:8000/admin")
		driver.find_element_by_name('username').send_keys('louis')
		driver.find_element_by_name('password').send_keys('wordpass')
		driver.find_element_by_xpath('//input[@type="submit"]').click()
		goal_status = driver.find_element_by_partial_link_text('Goal status').get_attribute('innerHTML').rstrip('\n')
		scrumy_goals = driver.find_element_by_partial_link_text('Scrumy goals').get_attribute('innerHTML').rstrip('\n')
		scrumy_history = driver.find_element_by_partial_link_text('Scrumy historys').get_attribute('innerHTML').rstrip('\n')
		if goal_status and scrumy_goals and scrumy_history:
			task_1 += 1
			task_5 += 1
	except Exception as e:
		task_1 = 0


	try:
		driver.find_element_by_partial_link_text('Scrumy goals').click()
		driver.find_element_by_class_name('addlink').click()
		task_name = driver.find_element_by_name('task_name').get_attribute('name')
		task_id = driver.find_element_by_name('task_id').get_attribute('name')
		created_by = driver.find_element_by_name('created_by').get_attribute('name')
		moved_by = driver.find_element_by_name('moved_by').get_attribute('name')
		owner = driver.find_element_by_name('owner').get_attribute('name')
		goal_status = driver.find_element_by_name('goal_status').get_attribute('name')
		user = driver.find_element_by_name('user').get_attribute('name')

		if task_name and task_id and created_by and moved_by and owner and goal_status and user:
			task_2 += 1
			task_3 += 1
			task_4 += 1
	except Exception as e:
		task_2 = 0
		task_3 = 0
	
	try:
		driver.find_element_by_partial_link_text('Home').click()
		driver.find_element_by_partial_link_text('Scrumy historys').click()
		driver.find_element_by_class_name('addlink').click()

		created_by = driver.find_element_by_name('created_by').get_attribute('name')
		moved_by = driver.find_element_by_name('moved_by').get_attribute('name')
		moved_from = driver.find_element_by_name('moved_from').get_attribute('name')
		moved_to = driver.find_element_by_name('moved_to').get_attribute('name')
		time_0 = driver.find_element_by_name('time_of_action_0').get_attribute('name')
		time_1 = driver.find_element_by_name('time_of_action_1').get_attribute('name')
		task_name = driver.find_element_by_name('task').get_attribute('name')

		print(created_by, moved_by,moved_from,moved_to,time_0,time_1,task_name)
		if created_by and moved_by and moved_from and moved_to and time_0 and time_1 and task_name:
			task_4 += 1
	except Exception as e:
		task_4 = 0
	print(task_1, task_2, task_3, task_4, task_5)
	x = task_1 + task_2 + task_3 + task_4 + task_5
	if x > 5:
		grade = 'Passed'
		mark = (task_1 + task_2 + task_3 + task_4 + task_5)/6 * 100
	else:
		grade = 'Failed'
		mark = (task_1 + task_2 + task_3 + task_4 + task_5)/6 * 100

	save_grade(lab_number, mark, current_user, grade)
	return(grade)



'''
def handle_lab9_uploaded_file(file, lab_number, current_user):
	file_name = file.name
	file_upload =  os.path.join(PROJECT_MEDIA_DIR, file.name)
	app_name = current_user.last_name + 'scrumy'
	grade = ''
	my_list = ''


	subprocess.call(["pip", "install", file_upload])

	os.system('python manage.py makemigrations')
	os.system('python manage.py migrate')


	with open(PROJECT_DIR + '\\settings.py', 'r') as settings_file:
		for eachline in settings_file:
			if eachline.rstrip('\n') == "    "+"'"+app_name+"'"+",":
				my_list = eachline

	
	print('mylist == '+ my_list)

	if my_list != '':

		grade = ''
		mark = 0
		task_1 = 0
		task_2 = 0
		task_3 = 0
		task_4 = 0
		task_5 = 0

		driver = webdriver.Chrome(os.path.join(BASE_DIR, 'chromedriver.exe'))

		try:
			driver.get("http://127.0.0.1:8000/admin")
			driver.find_element_by_name('username').send_keys('louiseyoma')
			driver.find_element_by_name('password').send_keys('wordpass')
			driver.find_element_by_xpath('//input[@type="submit"]').click()
			goal_status = driver.find_element_by_partial_link_text('Goal status').get_attribute('innerHTML').rstrip('\n')
			scrumy_goals = driver.find_element_by_partial_link_text('Scrumy goals').get_attribute('innerHTML').rstrip('\n')
			scrumy_history = driver.find_element_by_partial_link_text('Scrumy historys').get_attribute('innerHTML').rstrip('\n')
			if goal_status and scrumy_goals and scrumy_history:
				task_1 += 1
				task_5 += 1
		except Exception as e:
			task_1 = 0


		try:
			driver.find_element_by_partial_link_text('Scrumy goals').click()
			driver.find_element_by_class_name('addlink').click()
			task_name = driver.find_element_by_name('task_name').get_attribute('name')
			task_id = driver.find_element_by_name('task_id').get_attribute('name')
			created_by = driver.find_element_by_name('created_by').get_attribute('name')
			moved_by = driver.find_element_by_name('moved_by').get_attribute('name')
			owner = driver.find_element_by_name('owner').get_attribute('name')
			goal_status = driver.find_element_by_name('goal_status').get_attribute('name')
			user = driver.find_element_by_name('user').get_attribute('name')

			if task_name and task_id and created_by and moved_by and owner and goal_status and user:
				task_2 += 1
				task_3 += 1
				task_4 += 1
		except Exception as e:
			task_2 = 0
			task_3 = 0
		
		try:
			driver.find_element_by_partial_link_text('Home').click()
			driver.find_element_by_partial_link_text('Scrumy historys').click()
			driver.find_element_by_class_name('addlink').click()

			created_by = driver.find_element_by_name('created_by').get_attribute('name')
			moved_by = driver.find_element_by_name('moved_by').get_attribute('name')
			moved_from = driver.find_element_by_name('moved_from').get_attribute('name')
			moved_to = driver.find_element_by_name('moved_to').get_attribute('name')
			time_0 = driver.find_element_by_name('time_of_action_0').get_attribute('name')
			time_1 = driver.find_element_by_name('time_of_action_1').get_attribute('name')
			task_name = driver.find_element_by_name('task').get_attribute('name')

			print(created_by, moved_by,moved_from,moved_to,time_0,time_1,task_name)
			if created_by and moved_by and moved_from and moved_to and time_0 and time_1 and task_name:
				task_4 += 1
		except Exception as e:
			task_4 = 0
		print(task_1, task_2, task_3, task_4, task_5)
		x = task_1 + task_2 + task_3 + task_4 + task_5
		if x > 5:
			grade = 'Passed'
			mark = (task_1 + task_2 + task_3 + task_4 + task_5)/6 * 100
		else:
			grade = 'Failed'
			mark = (task_1 + task_2 + task_3 + task_4 + task_5)/6 * 100

		save_grade(lab_number, mark, current_user, grade)
	else:
		replace(os.path.join(PROJECT_DIR, 'settings.py'), 'INSTALLED_APPS = [', "INSTALLED_APPS = [\n    '"+app_name+"',")
		replace(os.path.join(PROJECT_DIR, 'urls.py'), 'urlpatterns = [', "urlpatterns = [\n    path('"+ app_name +"/', include('"+ app_name +".urls')),")
		

		grade = ''
		mark = 0
		task_1 = 0
		task_2 = 0
		task_3 = 0
		task_4 = 0
		task_5 = 0

		driver = webdriver.Chrome(os.path.join(BASE_DIR, 'chromedriver.exe'))

		try:
			driver.get("http://127.0.0.1:8000/admin")
			driver.find_element_by_name('username').send_keys('louiseyoma')
			driver.find_element_by_name('password').send_keys('wordpass')
			driver.find_element_by_xpath('//input[@type="submit"]').click()
			goal_status = driver.find_element_by_partial_link_text('Goal status').get_attribute('innerHTML').rstrip('\n')
			scrumy_goals = driver.find_element_by_partial_link_text('Scrumy goals').get_attribute('innerHTML').rstrip('\n')
			scrumy_history = driver.find_element_by_partial_link_text('Scrumy historys').get_attribute('innerHTML').rstrip('\n')
			if goal_status and scrumy_goals and scrumy_history:
				task_1 += 1
				task_5 += 1
		except Exception as e:
			task_1 = 0


		try:
			driver.find_element_by_partial_link_text('Scrumy goals').click()
			driver.find_element_by_class_name('addlink').click()
			task_name = driver.find_element_by_name('task_name').get_attribute('name')
			task_id = driver.find_element_by_name('task_id').get_attribute('name')
			created_by = driver.find_element_by_name('created_by').get_attribute('name')
			moved_by = driver.find_element_by_name('moved_by').get_attribute('name')
			owner = driver.find_element_by_name('owner').get_attribute('name')
			goal_status = driver.find_element_by_name('goal_status').get_attribute('name')
			user = driver.find_element_by_name('user').get_attribute('name')

			if task_name and task_id and created_by and moved_by and owner and goal_status and user:
				task_2 += 1
				task_3 += 1
				task_4 += 1
		except Exception as e:
			task_2 = 0
			task_3 = 0
		
		try:
			driver.find_element_by_partial_link_text('Home').click()
			driver.find_element_by_partial_link_text('Scrumy historys').click()
			driver.find_element_by_class_name('addlink').click()

			created_by = driver.find_element_by_name('created_by').get_attribute('name')
			moved_by = driver.find_element_by_name('moved_by').get_attribute('name')
			moved_from = driver.find_element_by_name('moved_from').get_attribute('name')
			moved_to = driver.find_element_by_name('moved_to').get_attribute('name')
			time_0 = driver.find_element_by_name('time_of_action_0').get_attribute('name')
			time_1 = driver.find_element_by_name('time_of_action_1').get_attribute('name')
			task_name = driver.find_element_by_name('task').get_attribute('name')

			print(created_by, moved_by,moved_from,moved_to,time_0,time_1,task_name)
			if created_by and moved_by and moved_from and moved_to and time_0 and time_1 and task_name:
				task_4 += 1
		except Exception as e:
			task_4 = 0
		print(task_1, task_2, task_3, task_4, task_5)
		x = task_1 + task_2 + task_3 + task_4 + task_5
		if x > 5:
			grade = 'Passed'
			mark = (task_1 + task_2 + task_3 + task_4 + task_5)/6 * 100
		else:
			grade = 'Failed'
			mark = (task_1 + task_2 + task_3 + task_4 + task_5)/6 * 100
		save_grade(lab_number, mark, current_user, grade)
	return (grade)
'''




def grade_django_lab8(file, lab_number, current_user):


	file_upload = ''

	if file.name.endswith('.zip'):
		file_upload = os.path.join(PROJECT_MEDIA_DIR, current_user.username + '_' + lab_number + '.zip')
	else:
		file_upload = os.path.join(PROJECT_MEDIA_DIR, current_user.username + '_' + lab_number + '.gz')

	app_name = current_user.last_name + 'scrumy'
	grade = ''
	mark = 0
	count = 0

	try:
		subprocess.call([sys.executable, "-m", "pip", "install", file_upload])

		print ("Initializing webdriver...")
		driver = webdriver.Chrome(os.path.join(BASE_DIR, 'chromedriver.exe'))
		print ("webdriver initialized")

		driver.get("http://127.0.0.1:8000/"+app_name)

		html = driver.find_element_by_xpath('//body').get_attribute('innerHTML')
		
		
		if html.rstrip('\n').lower() == 'hello world':
			grade = "Passed"
			mark = 100
			print('Passed')
		else:
			print('Failed')
			grade = 'Failed'
			mark = 0
		save_grade(lab_number, mark, current_user, grade) 
	except Exception as e:
		grade = 'Failed'
		mark = 0
		save_grade(lab_number, mark, current_user, grade)
		print(e)
	finally:
		os.remove(file_upload)

	return(grade)

'''
def handle_lab8_uploaded_file(file, lab_number, current_user):
	file_name = file.name
	file_upload =  os.path.join(PROJECT_MEDIA_DIR, file.name)
	app_name = current_user.last_name + 'scrumy'
	grade = ''
	my_list = ''


	subprocess.call([sys.executable, "-m", "pip", "install", file_upload])
	#os.system('python manage.py makemigrations')
	#os.system('python manage.py migrate')


	with open(os.path.join(PROJECT_DIR + '/settings.py'), 'r') as settings_file:
		for eachline in settings_file:
			if eachline.rstrip('\n') == "    "+"'"+app_name+"'"+",":
				my_list = eachline

	
	print('mylist == '+ my_list)

	if my_list != '':

		grade = ''
		mark = 0

		print ("Initializing webdriver...")
		driver = webdriver.Chrome(os.path.join(BASE_DIR, 'chromedriver.exe'))
		print ("webdriver initialized")

		driver.get("http://127.0.0.1:8000/"+app_name)

		#html = driver.execute_script("return document.body.innerHTML;")
		html = driver.find_element_by_xpath('//body').get_attribute('innerHTML')
		
		
		if html.rstrip('\n').lower() == 'hello world':
			grade = "Passed"
			mark = 100
			print('Passed')
		else:
			print('Failed')
			grade = 'Failed'
			mark = 0
		save_grade(lab_number, mark, current_user, grade)
	else:
		grade = ''
		mark = 0

		replace(os.path.join(PROJECT_DIR, 'settings.py'), 'INSTALLED_APPS = [', "INSTALLED_APPS = [\n    '"+app_name+"',")
		replace(os.path.join(PROJECT_DIR, 'urls.py'), 'urlpatterns = [', "urlpatterns = [\n    path('"+ app_name +"/', include('"+ app_name +".urls')),")
		

		#os.system('python manage.py makemigrations' + appname)
		#os.system('python manage.py migrate')
		driver = webdriver.Chrome(os.path.join(BASE_DIR, 'chromedriver.exe'))



		driver.get("http://127.0.0.1:8000/"+app_name)
		html = driver.find_element_by_xpath('//body').get_attribute('innerHTML')


		if html.rstrip('\n').lower() == 'hello world':
			grade = "Passed"
			mark = 100
		else:
			grade = 'Failed'
			mark = 0
		save_grade(lab_number, mark, current_user, grade)

	return (grade)
'''



def grade_django_lab7(file, lab_number, current_user):

	file_upload = ''

	if file.name.endswith('.zip'):
		file_upload = os.path.join(PROJECT_MEDIA_DIR, current_user.username + '_' + lab_number + '.zip')
	else:
		file_upload = os.path.join(PROJECT_MEDIA_DIR, current_user.username + '_' + lab_number + '.gz')

	app_name = current_user.last_name + 'scrumy'
	grade = ''
	mark = 0
	count = 0
	my_list = ''

	try:
		subprocess.call([sys.executable, "-m", "pip", "install", file_upload])
		count += 1
		os.remove(file_upload)
	except Exception as e:
		print (e)
		print('error')
		grade = 'failed'
		mark = 0

	if count > 0:
		grade = 'Passed'
		mark = 100
		save_grade(lab_number, mark, current_user, grade)
		with open(os.path.join(PROJECT_DIR + '/settings.py'), 'r') as settings_file:
			for eachline in settings_file:
				if eachline.rstrip('\n') == "    "+"'"+app_name+"'"+",":
					my_list = eachline
		
		if my_list == '':
			replace(os.path.join(PROJECT_DIR, 'settings.py'), 'INSTALLED_APPS = [', "INSTALLED_APPS = [\n    '"+app_name+"',")
			replace(os.path.join(PROJECT_DIR, 'urls.py'), 'urlpatterns = [', "urlpatterns = [\n    path('"+ app_name +"/', include('"+ app_name +".urls')),")
	return (grade)




'''
def grade_django_lab7(file, lab_number, current_user):
	file_upload =  os.path.join(PROJECT_MEDIA_DIR, file.name)
	grade = ''
	mark = 0
	count = 0

	if file.name.endswith('tar.gz'):
		extracted_file = file.name.rstrip('.tar.gz')
		tar = tarfile.open('file_upload')
		tar.extractall(MEDIA_DIR)
		tar.close()

		with open(os.path.join(MEDIA_DIR, extracted_file + 'django_' + current_user.last_name + 'scrumy.egg-info/SOURCES.txt'), 'r') as source_file:
			for eachline in source_file:
				if eachline.rstrip('\n') == 'MANIFEST.in' or eachline.rstrip('\n') == 'README.rst' or eachline.rstrip('\n') == 'setup.py' or eachline.rstrip('\n') == current_user.last_name + 'scrumy/__init__.py':
					count += 1
		
		if count == 4:
			mark = 100
			grade = 'Passed'
		else:
			mark = 0
			grade = 'Failed'
	elif file.name.endswith('.zip'):
		extracted_file = file.name.rstrip('.zip')
		try:
			zfile = zipfile.ZipFile(file)
		except zipfile.BadZipfile as ex:
			print("%s no a zip file" % file)

		zfile.extractall(MEDIA_DIR)
		with open(os.path.join(MEDIA_DIR, extracted_file + '/django_' + current_user.last_name + 'scrumy.egg-info/SOURCES.txt'), 'r') as source_file:
			for eachline in source_file:
				if eachline.rstrip('\n') == 'MANIFEST.in' or eachline.rstrip('\n') == 'README.rst' or eachline.rstrip('\n') == 'setup.py' or eachline.rstrip('\n') == current_user.last_name + 'scrumy/__init__.py':
					count += 1

		print(count)

		if count == 4:
			mark = 100
			grade = 'Passed'
		else:
			mark = 0
			grade = 'Failed'
	else:
		grade = Failed
		mark = 0
	
	save_grade(lab_number, mark, current_user, grade)

	return (grade)
'''

def grade_django_lab6(file, lab_number, current_user):

	match_count = 0
	grade = ''
	mark = 0

	if file.name.endswith('.sql'):
		try:
			with open(os.path.join(PROJECT_MEDIA_DIR, current_user.username + '_' + lab_number + '.sql'), 'r') as sql_database:
				for each_line in sql_database:
					if each_line.rstrip('\n') == "INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES":
						match_count += 1

			mark = 100 * match_count/1
			if mark > 69:
				grade = "Passed"
			else:
				grade = "Failed"
		except Exception as e:
			print(e)
			grade = 'Failed'
	os.remove(os.path.join(PROJECT_MEDIA_DIR, current_user.username + '_' + lab_number + '.sql'))
	save_grade(lab_number, mark, current_user, grade)
	return (grade)



def grade_django_lab5(file, lab_number, current_user):
	match_count = 0
	grade = ''
	mark = 0

	if file.name.endswith('.sql'):
		try:
			with open(os.path.join(PROJECT_MEDIA_DIR, current_user.username + '_' + lab_number + '.sql'), 'r') as sql_database:
				for each_line in sql_database:
					if each_line.rstrip('\n') == "CREATE TABLE IF NOT EXISTS `django_migrations` (" or each_line.rstrip('\n') == "CREATE TABLE IF NOT EXISTS `django_admin_log` (" or each_line.rstrip('\n') == "CREATE TABLE IF NOT EXISTS `django_session` (":
						match_count += 1
			
			mark = 100 * match_count/3
			if mark > 69:
				grade = "Passed"
			else:
				grade = "Failed"
		except Exception as e:
			print(e)
			grade = 'Failed'
	os.remove(os.path.join(PROJECT_MEDIA_DIR, current_user.username + '_' + lab_number + '.sql'))
	save_grade(lab_number, mark, current_user, grade)
	return (grade)




def grade_django_lab4(file, lab_number, current_user):

	count = 0
	grade = ''
	mark = 0


	print(file.name)
	if file.name.startswith('settings'):
		try:
			with open(os.path.join(PROJECT_MEDIA_DIR, current_user.username + '_' + lab_number + '.py'), 'r') as settings_file:
				for eachline in settings_file:
					if eachline.rstrip('\n') == "        'ENGINE': 'django.db.backends.sqlite3'," or eachline.rstrip('\n') == "        'NAME': os.path.join(BASE_DIR, 'db.sqlite3'),":
						count += 1

			if count > 1:
				grade = 'Passed'
				mark = 100
			else:
				grade = 'Failed'
				mark = 0
		except Exception as e:
			print (e)
			grade = 'Failed'
	else:
		grade = 'Failed'	
	os.remove(os.path.join(PROJECT_MEDIA_DIR, current_user.username + '_' + lab_number + '.py'))
	save_grade(lab_number, mark, current_user, grade)
	return (grade)




def grade_django_lab3(file, surname, lab_number, current_user):
	zfile = ''
	zfile_name = file.name
	exfile_name = zfile_name.rstrip('.zip')
	task_1= 0
	task_3 = 0
	task_4 = 0
	task_5 = 0
	task_6 = 0
	grade = ''
	mark = 0


	if zfile_name.endswith('.zip'):	
		try:
			zfile = zipfile.ZipFile(file)
		except zipfile.BadZipfile as ex:
			print("%s no a zip file" % file)

		ret = zfile.testzip()
	
		if ret is not None:
			grade = 'Failed'
			print("%s is a bad zip file, error: %s" % file, ret)
		else:
			lab_docs = zfile.extractall(MEDIA_DIR)

			for root, dirs, files in os.walk(MEDIA_DIR):
				for dirnames in dirs:
					if dirnames == 'myscrumy':
						task_1 += 1
				for dirnames in dirs:
					if dirnames == surname + 'scrumy':
						task_3 += 1
				for file in files:
					if file.endswith('dmin.py') or file.endswith('odels.py') or file.endswith('iews.py') or file.endswith('ests.py') or file.endswith('pps.py'):
						task_3 += 1
				for file in files:
					if file.endswith('rls.py'):
						task_4 += 1

			with open(os.path.join(MEDIA_DIR, 'myscrumy/' + surname +'scrumy/urls.py'), 'r') as project_url:
				for eachline in project_url:
					if eachline.rstrip('\n') == "    path('"+surname+"scrumy/', include("+'"'+surname+'scrumy.urls")),' or eachline.rstrip('\n') == "    path('"+surname+"scrumy/', include('"+surname+"scrumy.urls'))," or eachline.rstrip('\n') == '    path("'+surname+'scrumy/", include('+"'"+surname+"scrumy.urls'))," or eachline.rstrip('\n') == '    path("'+surname+'scrumy/", include("'+surname+'scrumy.urls")),':
						task_5 += 1

			with open(os.path.join(MEDIA_DIR, 'myscrumy/'+surname+'scrumy/urls.py'), 'r') as app_url:
				for eachline in app_url:
					if eachline.rstrip('\n') == "    path('', views.index)," or eachline.rstrip('\n') == '    path("", views.index),':
						task_6 += 1
			shutil.rmtree(MEDIA_DIR+'/myscrumy')

			mark = 100* (task_1 + task_3 + task_4 + task_5 + task_6)/12

			if mark < 70:
				grade = "failed"
			else:
				grade = "passed"
	else:
		grade = 'Failed'
	save_grade(lab_number, mark, current_user, grade)
	return(grade)






def grade_django_lab2(file, surname, lab_number, current_user):

	count = 0
	grade = 0
	mark = 0


	print(file.name)
	if file.name.rstrip('\n').endswith('.txt'):
		
		try:
			with open(os.path.join(PROJECT_MEDIA_DIR, file.name), 'r') as fil:
				for eachline in fil:
					if eachline.rstrip('\n') == 'Django==2.0.1':
						count += 1
			
			if count > 1:
				grade = 'Passed'
				mark = 100
			else:
				grade = 'Failed'
				mark = 0
		except Exception as e:
			grade = 'Failed'
			mark = 0
			print(e)
	else:
		grade = 'Failed'
		mark = 0

	save_grade(lab_number, mark, current_user, grade)
	return (grade)