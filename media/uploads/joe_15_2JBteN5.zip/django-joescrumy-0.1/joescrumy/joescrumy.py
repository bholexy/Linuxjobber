from django.contrib.models import User
from .models import ScrumyGoals, GoalStatus

u = User(first_name = 'louis', last_name = 'oma', username = 'louisoma', email = 'louisoma@linuxjobber.com', password = 'linuxjobber' )
u.save()

g1 = GoalStatus(status_name = 'Weekly Goals')
g1.save()
g2 = GoalStatus(status_name = 'Daily Goals')
g2.save()
g3 = GoalStatus(status_name = 'Verify Goals')
g3.save()
g4 = GoalStatus(status_name = 'Done Goals')
g4.save()


goal = ScrumyGoals(task_name='Learn Django', task_id=1, created_by='Louis', moved_by = 'Louis', owner='Louis', goal_status= g1, user = u)
goal.save()