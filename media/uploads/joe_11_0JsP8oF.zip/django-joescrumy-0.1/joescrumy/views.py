from django.shortcuts import render
from django.http import HttpResponse
from staticscrumy.models import *

# Create your views here.

def index(request):
	output = ScrumyGoals.objects.filter(task_name = 'Learn Python')
	return HttpResponse(output)