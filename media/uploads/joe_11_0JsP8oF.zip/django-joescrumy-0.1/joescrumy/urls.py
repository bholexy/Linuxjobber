from django.urls import path
from joescrumy import views


urlpatterns = [
	
	path('', views.index)
	
]