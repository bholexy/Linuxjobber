from django.apps import AppConfig


class JoescrumyConfig(AppConfig):
    name = 'joescrumy'
