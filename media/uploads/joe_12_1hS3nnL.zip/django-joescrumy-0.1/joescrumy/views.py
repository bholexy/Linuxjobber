from django.shortcuts import render
from django.http import HttpResponse
from staticscrumy.models import *

# Create your views here.

def index(request):
	output = ScrumyGoals.objects.filter(task_name = 'Learn Python')
	return HttpResponse(output)




def move_goal(request, goal_id):
	output = ScrumyGoals.objects.get(goal_id = goal_id)
	return HttpResponse(output)