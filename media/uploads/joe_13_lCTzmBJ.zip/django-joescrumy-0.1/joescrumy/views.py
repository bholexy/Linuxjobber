from django.shortcuts import render
from django.http import HttpResponse
from .models import *

import random

# Create your views here.

def index(request):
	output = ScrumyGoals.objects.filter(goal_name = 'Learn Python')
	return HttpResponse(output)




def move_goal(request, goal_id):
	output = ScrumyGoals.objects.get(goal_id = goal_id)
	return HttpResponse(output)



def add_goal(request):

	random_number = 1
	rec = ScrumyGoals.objects.get(goal_id = random_number)

	while rec.goal_id == random_number:
		random_number = random.randint(1000,9999)

	status1 = GoalStatus.objects.get(status_name = 'Weekly Goal')
	user = User.objects.get(email = 'louisoma@linuxjobber.com')
		
	record = ScrumyGoals(goal_name = 'Keep Learning Django', goal_id = 2, created_by = 'Louis', moved_by = 'Louis', owner = 'Louis', goal_status = status1, user = user)
	record.save()

	return HttpResponse()



def home(request):
	record = ScrumyGoals.objects.get(goal_name = 'Keep Learning Django')
	return HttpResponse(record)
